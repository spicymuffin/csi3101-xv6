#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock); // how did it know abt tickslock in trap.c???
  ticks0 = ticks; // sleep start tick cached
  while(ticks - ticks0 < n){ // while we didnt sleep enough
    if(myproc()->killed){ // if we were killed while sleeping
      release(&tickslock);
      return -1; // exit, release tickslock
    }
    sleep(&ticks, &tickslock); // sleep (give control to other processes)
                               // sleep on channel ticks (is this system's total tick count?)
                               // but mark myself as sleeping
                               // releases tickslock but reacquires it
                               // before exiting sleep()
                               // also starts a scheduling round inside
  }
  release(&tickslock);
  return 0;
}

int
sys_nice(void)
{
  int v;
  if(argint(0, &v) < 0)
    return -1;
  return nice(v);
}

int
sys_ps(void)
{
  ps();
  return 0; 
}

int
sys_yield(void)
{
  yield();
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
